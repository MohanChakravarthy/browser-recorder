// ai_activity_indicator.js - amber "AI" border and a two-line yellow status badge.
// Loaded by Playwright MCP's --init-script (every page it opens), and injected by
// ai_session.py / ai_activity_indicator.py on pages driven by Robot or rf-mcp.
// Safe: ignores the mouse (pointer-events: none), text lives in a closed shadow root (text
// checks and locators never see it), styles are set from script (works with strict CSP),
// all errors swallowed. Colours: amber glow, yellow badge, black and dark grey text, so it
// stands out on blue application themes.
// Update from the AI:  window.__aiSetLabel('Reviewing this page', 'Search Client')
//   line 1 = what is happening (plain English), line 2 = "Keyword: <name>" (hidden if empty)
(() => {
  try {
    if (window.top !== window.self) return;            // main page only, not inside frames
    const DEFAULT = window.__aiLabelText || 'AI assistant is reviewing this page';
    window.__aiSetLabel = (text, keyword) => {
      try {
        window.__aiLabelText = String(text || DEFAULT).slice(0, 90);
        window.__aiKeywordText = keyword ? String(keyword).slice(0, 80) : '';
        if (window.__aiLine1) window.__aiLine1.textContent = window.__aiLabelText;
        if (window.__aiLine2) {
          window.__aiLine2.textContent = window.__aiKeywordText ? 'Keyword: ' + window.__aiKeywordText : '';
          window.__aiLine2.style.display = window.__aiKeywordText ? 'block' : 'none';
        }
      } catch (e) {}
    };
    const draw = () => {
      try {
        if (document.getElementById('ai-activity-indicator')) return;
        const root = document.documentElement;
        if (!root) return;
        const d = document.createElement('div');
        d.id = 'ai-activity-indicator';
        d.setAttribute('aria-hidden', 'true');
        Object.assign(d.style, { position: 'fixed', top: '0', left: '0', right: '0', bottom: '0',
          pointerEvents: 'none', zIndex: '2147483647', borderRadius: '6px',
          boxShadow: 'inset 0 0 0 3px rgba(245,158,11,0.95), inset 0 0 28px 6px rgba(253,224,71,0.55)' });
        const sr = d.attachShadow({ mode: 'closed' });
        const badge = document.createElement('div');
        Object.assign(badge.style, { position: 'absolute', top: '10px', right: '14px', maxWidth: '60vw',
          background: '#FFD60A', color: '#111111', border: '1px solid #B45309', borderRadius: '10px',
          padding: '7px 12px', boxShadow: '0 2px 10px rgba(0,0,0,0.30)',
          font: '13px/1.35 Segoe UI, Arial, sans-serif' });
        const l1 = document.createElement('div');
        Object.assign(l1.style, { fontWeight: '700', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' });
        const l2 = document.createElement('div');
        Object.assign(l2.style, { fontWeight: '500', fontSize: '12px', color: '#3F3F46', whiteSpace: 'nowrap',
          overflow: 'hidden', textOverflow: 'ellipsis', marginTop: '2px' });
        badge.appendChild(l1); badge.appendChild(l2);
        sr.appendChild(badge);
        window.__aiLine1 = l1; window.__aiLine2 = l2;
        window.__aiSetLabel(window.__aiLabelText || DEFAULT, window.__aiKeywordText || '');
        root.appendChild(d);
        if (d.animate) d.animate([
          { boxShadow: 'inset 0 0 0 2px rgba(245,158,11,0.7), inset 0 0 14px 2px rgba(253,224,71,0.35)' },
          { boxShadow: 'inset 0 0 0 4px rgba(245,158,11,1), inset 0 0 40px 10px rgba(253,224,71,0.75)' }
        ], { duration: 1600, iterations: Infinity, direction: 'alternate', easing: 'ease-in-out' });
      } catch (e) {}
    };
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', draw, { once: true });
    draw();
    try { new MutationObserver(() => { if (!document.getElementById('ai-activity-indicator')) draw(); })
      .observe(document.documentElement, { childList: true }); } catch (e) {}
  } catch (e) {}
})();
