---
name: robot-script-generator
description: Generates proven Robot Framework test scripts from AIDLC test cases (a test case ID, a test case .md file, a whole file in batch mode, or a plain-language request), including new features shown only on standalone mock screens. Known steps always run with the repo's real keywords (through rf-mcp, or a normal Robot run), new UI parts are explored with Playwright MCP, every new locator is proven in the test's own library before it is written, and only a normal headed Robot run can produce a PASS. Diagnoses environment problems before touching a script, never replaces existing keywords without proof and approval, shows a task list with ticks, works in ai_generated_tests/drafts and moves only passing tests to ai_generated_tests/verified, then asks before adding anything to the suite, branching or committing. Never writes sensitive data into code. Use when asked to generate, create, write or automate a test script.
version: 2.4.0
---

# Robot Script Generator

## 1. Non-negotiable rules
1. **Ask before changing the repo.** Never add to existing suite or resource files, switch branch, commit or push without the user's explicit answer to that stage's question. Planning, reaching the screen, exploring, writing the draft, running it and fixing it are automatic.
2. **Existing paths use existing keywords and locators only.** New keywords and locators are allowed only for elements or screens that are not in the knowledge. Never modify, reformat, rename, delete or bypass an existing test, keyword or locator.
3. **Never declare an existing keyword broken without proof.** If a known step fails, first assume your own setup or copy is wrong (frames, waits, data, missing setup, run configuration). A keyword counts as broken only if an existing repo test that uses it also fails the same way (section 6). Even then, explain the evidence and ask before using any replacement.
4. **Diagnose before fixing.** Database, login, network, environment and test-data failures are never "fixed" in the script (section 6).
5. **Known steps run in Robot, never by hand.** Login, search, navigation and every other known step run with the repo's real keywords (rf-mcp or a normal Robot run). Playwright MCP never replays known steps.
6. **Every new locator is proven by the judge** (section 4) in the library the test uses before it is written.
7. **PASS means a full, normal, headed Robot run passed end to end** (section 8). A live-session result, dry run or partial run is never a PASS.
8. **Nothing goes to `ai_generated_tests/verified/` until it passes.** Work happens in `ai_generated_tests/drafts/`. Drafts are never staged or committed. (The folder is not git-ignored on purpose: some agents' file tools refuse to write into ignored folders.)
9. **No sensitive data in code text** (section 9). Real values live only in variables or data files.
10. **No hard-coded credentials or URLs.** Use the repo's variables, variable files, vault or environment variables, exactly as `knowledge/run-config.md` describes.
11. **Test environments only.** If the target looks like production or is unknown, stop and ask.
12. **No saving while exploring.** Never click Save, Submit, Delete, Approve or similar while exploring or probing. Tests perform those actions only when the test case requires them and the user has confirmed it is allowed in this environment (shared test-environment data).
13. **Log in once per session.** Run the setup chain (e.g. vault loading and login) exactly once per live session; running it twice can decode secrets twice and break login. If it breaks, start a new session; never retry login repeatedly (account lockout).
14. **No `Sleep`** unless the repo has no other wait mechanism. **Never weaken or remove an assertion to make a test pass.**
15. **Tell the story.** Keep the task list (section 19) current; post a short visible message at every stage change. Never work silently for more than about 2 minutes or 10 tool calls. Before anything slow (starting a session, opening the browser, a full run), say so first, e.g. "Starting the browser and logging in with your existing steps. This usually takes about a minute."
16. **Plain, professional English** in every chat message and badge, readable by a manager with no testing background: short sentences, no file paths, library names or error codes in the headline (details go below it), never data values.

## 2. Short requests (testers should not need long prompts)
Accept any of these and infer the rest from this skill:
- `@robot-script-generator TC-1234`
- `@robot-script-generator check address type HOME is available`
- `@robot-script-generator TC-1234 playwright`
- `@robot-script-generator path/to/test-cases.md` or `@robot-script-generator path/to/test-cases.md TC-1234`
**Finding the test case:** for a test case ID, search the repo's test case `.md` files (AIDLC output) for that ID and use its title, preconditions, steps, test data and expected results exactly. For an `.md` file, read it; if it holds several test cases and none is named, list their IDs and titles and ask which one. If an ID is not found or appears more than once, say so and ask. The test case is the source of truth: for new features its screen, section and element names are the starting hint for exploration (section 14), and its expected results become the assertions. Never add steps or checks it does not ask for.
- `@robot-script-generator <test cases .md> all` (batch mode, section 16); `@robot-script-generator <test cases .md> TC-1234 mock <mock link or .html file>` (mock mode, section 15). "all" and "mock" can be combined.
If the request has no test case ID and no description of what to check (e.g. only "execute", "run" or "generate"), do nothing else: never run existing suites or the whole repo. Ask: "Which test case ID or check do you want me to automate?" and wait.
If the input is a plain request, restate it as numbered steps and expected results and ask the user to confirm before continuing.

## 2a. Understanding the request (plain words to IDs)
1. Split the request into intents: target screens, elements, actions, data and expected outcomes. Example: "log in, select a client, go to addresses, tick Preferred Contact" -> logged in; client selected; SCREEN-CUSTOMER-ADDRESSES-TAB; element "Preferred Contact" checkbox; action check; outcome checkbox checked.
2. Resolve every word through `knowledge/glossary.md`, then screen and flow names, then keyword and locator meanings. Exact term first, then synonyms, then partial match.
3. One match: use it. Several matches (term marked ambiguous): ask the user one short question listing the options. No match: say so plainly, then treat it as unknown and explore it live (Stage 3) starting from the nearest known screen the user mentioned.
4. Unstated prerequisites are never the user's job: the route planner adds them ("go to addresses" automatically includes logging in and opening a client if the map says so).
5. **Remember the answer.** When the user picks one option for an ambiguous term, append it to `knowledge/glossary.md` as `<term> -> <ID>` with `Status: learned (needs review)`, the date and "chosen by user". Next time the term resolves without asking. Never store data values.

## 2b. Route planning (never invent a path)
1. Start state is logged out unless the repo's suite setup says otherwise.
2. For each target screen, read its entry in `knowledge/app-map.md`: preconditions, entry route, proof element.
3. Build the route by satisfying every precondition in order, using the entry routes exactly as copied from their source tests. Reuse the same keywords with the same arguments pattern (data as variables).
4. Never skip a precondition and never take a shortcut that no existing test takes, even if a tab or link looks directly clickable.
5. If two screens in the request need conflicting context, plan them in order and say so in the plan.
6. Show the route in the plan with the source test for each part.
7. **Test data:** list the data the route and actions need (e.g. a customer with saved addresses, a client in a given status). Take it from the data or variable files used by the route's source tests; reuse their variables. Never invent real data or hard-code it. If no suitable data exists, ask the user once for the variable to use. If the test creates or changes data, plan cleanup the way existing tests do.
8. **Run configuration:** read `knowledge/run-config.md` (normal run command, argument and variable files, environment variables needed, the suite-setup chain that loads the vault, headless switch, login retries). Every session and every draft must reproduce that setup exactly, once. If the file is missing, tell the user to run `@qa-knowledge-setup refresh`.

## 3. Pre-flight (read-only; report problems and stop if blocking)
1. Record current branch and commit. **Do not create or switch branches here.**
2. Knowledge exists: `app-knowledge.md`, `app-map.md`, `glossary.md`, `keyword-knowledge.md`, `locator-knowledge.md`, `run-config.md`. If any is missing or built by an older version, tell the user: "Run `@qa-knowledge-setup rebuild <scope>` first." Never plan routes without the map.
3. Freshness: if relevant suites or resources changed after the knowledge `last_commit`, warn and offer `@qa-knowledge-setup refresh`.
4. `knowledge/knowledge-status.md`: PASS continue; WARN warn and continue; FAIL or needs-human-review ask for explicit confirmation.
5. Environment from `run-config.md`: URL, credential and vault variables, required environment variables; confirm non-production.
6. Read `knowledge/lessons.md` and apply every lesson that matches the screens and keywords in this request.
7. Tools available (section 4). Note which fallback level (section 5, Stage 2) this run will use, and say it in one line.
8. `.gitignore` contains `knowledge/.extract/` and `.ai_session/`. If not, tell the user the lines to add before continuing. Do not add `ai_generated_tests/drafts/` to it.

## 4. Roles and tools (one job per part)
The tools never talk to each other directly. You (the agent following this skill) are the hub. They share three things: you, one live browser, and the session folder `.ai_session/` (`state.json` records who is in control, the screen, the frame and the door; `candidates.json` holds candidate locators; `proven.json` the judged ones).

| Part | Role | Job | Never |
|---|---|---|---|
| You, the agent | Hub | Plan, decide, pass control, write, report | Write a locator that was not proven |
| rf-mcp (Robot Framework MCP) | Hands | Run known steps live with the repo's real keywords: run configuration, vault, frames, login | Run setup or login twice in one session |
| Playwright MCP | Eyes | Look at new parts only: on the live page through the door, or on a mock screen | Run known steps, navigate away, save data |
| `AI Check Locator` (in `skills/ai_session.py`) | Judge | Prove each new locator: exactly one visible match, right frame, the action really changes state | Be skipped |
| Normal `robot` run | Proof | The only source of PASS | Be replaced by a session result |

**Helper library `ai_session.py`** (find it by name under `skills/`; import it only in AI sessions and drafts, never in team files): `AI Save Screen` (main page, every frame, a controls list, a screenshot into `.ai_session/screens/`), `AI Open Door` (save the screen and open a local door at `http://127.0.0.1:9222` to the same browser; does not block), `AI Close Door`, `AI Checkpoint` (for a normal Robot run: open the door and pause until `.ai_session/continue` exists or a time limit), `AI Check Locator`, `AI Set Label`.

**Two Playwright MCP entries** (see `setup/mcp-config-examples/`): `playwright` (its own browser: mock screens, standalone pages) and `playwright-attach` (joins the browser behind the door through its CDP endpoint `http://127.0.0.1:9222`). Both load `skills/ai_activity_indicator.js` as their init script, so the yellow badge appears automatically.

**Locator priority for new elements:** `data-testid`/`data-qa` > stable unique `id` > `name` > label-anchored CSS or short relative XPath > visible text. Never absolute XPath, index-based or generated IDs. Translate Playwright's role/label view into the repo's library syntax (e.g. SeleniumLibrary `id:`, `css:`, `xpath:`), then judge it. A candidate that fails the judge is dropped, never "fixed" by guessing.

## 5. Staged workflow

### Stage 0 - Task list
Create the task list (section 19) from the user's own steps, before any other work.

### Stage 0b - Environment and start-up check (always, before planning)
1. **Ask one question**, listing the environments found in `run-config.md` (and the repo's environment or variable files): "Which environment should I use: <A>, <B> or <C>? Once you choose, I will check every connection (secrets, database, application, browser) before running anything, and I will only continue if all of them work." Never assume the suite file's default. If the user already named the environment in the request, confirm it in one line instead of asking.
2. **Run the check** with the chosen environment, the normal way from `run-config.md` (a short Robot run `ai_generated_tests/drafts/_startup_check.robot` with the target suite's settings, or the rf-mcp session if it will be used):
   - Secrets / vault: the suite setup chain runs once without error.
   - Required variables: `AI Check Variables` with the URL, user and connection variable names from `run-config.md` (it reports OK / EMPTY / MISSING, never values).
   - Database: only if the route uses data from a query, run that same existing keyword once.
   - Application: the existing login keyword reaches the home screen (its proof element).
   - Browser: the browser opens headed.
   - rf-mcp (only if used): the session runs from the run-config working folder, and the same variables resolve inside it.
3. **Report a plain-English table**: `| Check | Result | What it means |`, e.g. "Database | Not working | The query returned no data: `<exact error>`". Mask passwords, tokens and connection strings.
4. **Continue only if every check passes.** Otherwise stop, name what failed, give the most likely fix (e.g. "the secrets loader did not receive the environment", "rf-mcp was started outside the repo folder"), and wait for "fixed, proceed". Start-up failures never use fix attempts. Close the browser after the check.

### Stage 1 - Understand and plan
Find the test case (section 2), resolve the request (2a), plan the route with every precondition (2b). Resolve every step against the knowledge: flow, flow step mapping, keyword, locator; prefer preferred duplicates, flow-level keywords, High then Medium stability locators. Mark each step **KNOWN** (existing keyword covers it), **PARTIAL** (screen known, element or keyword missing) or **NEW**.
Show: `| # | Your step | Known / New | Keyword or what will be explored | Source test |`
Mark the matching tasks. Continue without asking, unless a step is ambiguous, the test case is unclear, or the module's knowledge status is FAIL or needs-human-review. If every step is KNOWN, skip Stages 2 and 3.

### Stage 2 - Reach the screen with the real keywords (fallback ladder)
Use the highest level that works; say which one in one line. Every level ends with the judge and a normal Robot run.

| Level | Used when | Hands | How new parts are seen |
|---|---|---|---|
| 1 | rf-mcp and `playwright-attach` available, SeleniumLibrary + Chrome/Edge | rf-mcp | Saved screen files, then live Playwright through the door |
| 2 | Playwright cannot attach (door unavailable) | rf-mcp | Saved screen files, plus rf-mcp's own page keywords |
| 3 | rf-mcp unavailable or unstable | a short Robot "reach" run that ends with `AI Checkpoint` | Saved screen files, then live Playwright through the door while the run pauses |
| 4 | Nothing else can reach the screen | none | Playwright's own browser; the user logs in by hand in that window; you follow the full step list (section 5a) |

**Level 1-2 (rf-mcp):** start one session that reproduces a normal run exactly, using `run-config.md`:
- **Command-line variables first.** Before importing anything, set every variable the normal command passes (e.g. the environment: `--variable ENV:<env>` overrides the suite file's default), with `Set Global Variable`. Never use the suite file's default environment when the run config names a different one.
- **Working folder.** Imports may use `${EXECDIR}` (the folder robot is started from, normally the repo root) or `${CURDIR}`. If the rf-mcp session is not running from the run-config working folder, set `${EXECDIR}` to that folder before importing, or import those files with absolute paths built from it.
- **Imports.** The target suite's libraries, resources and variable files, with the same arguments (a variables file that takes the environment as an argument gets the run-config environment), plus `ai_session.py`. The secrets or vault loader is imported **exactly once**; importing it twice can break login.
- If an import cannot be resolved, stop and report the file and the import line; never fill in URLs, user names or secrets by hand.
 Run the suite-setup chain once, exactly as `run-config.md` lists it (folder init files may be `__init__.robot` or `__init__.txt`; when the run config says they have no setup, run none of them and do not ask), then the suite's own setup, so vault values load. Then run the KNOWN steps one keyword at a time with the same arguments the source test uses (data as variables). Run each existing keyword through `AI Run Step    <keyword>    <arguments...>` (badge before and after, timing recorded; section 18), and after each one apply the step verification protocol (section 12). If one keyword runs longer than `slow_keyword_limit` (default 90 seconds), tell the user in one line ("Logging in is taking longer than usual; still waiting") and keep waiting up to its own timeout; never type into the page while an existing keyword is still running. Stop at the first failure and go to section 6; Playwright never takes over a failed known step.
**Level 3 (reach run):** write `ai_generated_tests/drafts/<module>/_reach_<id>.robot` with the target suite's settings, the known steps only, and a last step `AI Checkpoint    timeout=600`. Run it headed in the background with the normal command from `run-config.md` (plus the indicator listener). Wait until `.ai_session/state.json` says `paused: true`. If the run fails before that, go to section 6.

### Stage 3 - Explore only the new parts
1. Run `AI Open Door` (Level 1-2; Level 3 already opened it). It saves the screen and returns the door URL or `NONE`.
2. **Read the saved files first** (`page.html`, `frames/*.html`, `frames.json`, `controls.json`, `screenshot.png`): search them for the test case's words. Often this is enough to build the candidate locators, with no live clicking.
3. If live inspection is needed and the door is open: use `playwright-attach`. Update the badge (`window.__aiSetLabel('Looking for <element name>')`). Inspect, open panels and dropdowns, read options. Never navigate away, close tabs, reload or save. Follow sections 13, 14 and 14a for discovery and budgets.
4. Write candidates to `.ai_session/candidates.json`: element meaning, frame path, candidate locator in the repo's syntax, evidence.
5. `AI Close Door` (Level 3: create `.ai_session/continue` instead; the run closes the door and finishes).
6. **Judge:** in the rf-mcp session (or a short Robot run), call `AI Check Locator    <locator>    frame=<frame path>    action=<check|uncheck|click|type|select>    value=<value>` for every candidate whose test step acts on it (no action for read-only elements). Only proven locators are used. Never judge Save/Submit/Delete buttons by clicking them; check them without an action.

### Stage 4 - Write the draft
Delete any earlier draft for the same test case. Write `ai_generated_tests/drafts/<module>/<test_case_id_or_short_name>.robot`: the target suite's settings (paths adjusted to this folder depth), the test, any new keywords and the new locators (new-feature resources go in their own file, section 15). Follow sections 9, 10 and 11.
- **Suite settings:** copy the target suite's Settings faithfully, including every Suite Setup / Teardown keyword (metadata, screenshots cleanup, profile setup). Never drop or skip a setup step silently. If a setup keyword needs a value the new suite does not have (e.g. a test-management key or suite name), pass the test case ID or a clearly named placeholder variable, mention it in the summary, and ask if its purpose is unclear.
- **No command-line values in files:** never hard-code the environment, output directory or any other variable the normal command passes (`run-config.md`); they come from the command line exactly as for the team's tests.
- **Reuse, don't wrap:** call existing keywords directly in the test. A new keyword that groups existing keywords for a known route is allowed only if it contains no locators, clicks or waits of its own; otherwise use the existing keywords step by step. Run `robot --dryrun` on it and fix syntax errors ("syntax OK", never "passed"). Tell the user the draft path, then go straight to Stage 5.

### Stage 5 - Run headed, fix, report
Run only the draft test with the normal command from `run-config.md`, headed (section 7), with `--listener <path to skills/ai_activity_indicator.py>` and `--outputdir results/ai-scriptgen`. Read the result strictly by section 8.
- **FAIL:** go to section 6 first. If the cause is environment or data: stop, report and wait. If the cause is the script: fix automatically and rerun the whole test, up to `max_fix_attempts` (default 3) rounds, one progress line per round ("Attempt 2 of 3: added the wait for the search frame, rerunning"). Never change an existing keyword or assertion to make it pass. If it still fails, explain in plain words: which step, what the screen showed, what each round tried, the most likely cause and the next action. Keep the draft in `drafts/` only. Leave the browser open on the failing screen so the user can look, and say: "I left the browser open on the screen where it stopped. Say **close** when you are done and I will close it and end the session." Whenever the user stops the run or says close, close every browser this run opened and end the rf-mcp session; never leave hidden sessions running.
- **PASS:** move the file to `ai_generated_tests/verified/<module>/` (same name; relative paths stay valid because the folder depth is the same) and use that path from now on. Delete `.ai_session/screens/` and `.ai_session/` login state. **Close every browser this run opened and end the rf-mcp session.**
Always show the exact command so the user can rerun it, and the traceability table `| TC step / expected result | Script line(s) | Run status |`, then the summary report (section 19).
**Ask (only after PASS):** "The test passed end to end. Please review the log and rerun it yourself with the command above. When you have finalised it, do you want me to add this test to the existing suite `<target suite file>`, or keep it only in `ai_generated_tests/verified/` for now?" If the user wants to rerun first, wait; do not ask again until they say they are done.

### Stage 6 - Add to the repository (only on yes)
Following the recorded test organisation: one-test-per-file → move the verified file to the module's test folder with a name in the repo's style; many-tests-per-suite → append the test at the end of the target suite's `*** Test Cases ***`. New locators and keywords go to the files recorded in the knowledge conventions, at the end of their sections; never insert inside existing tests or keywords; never import `ai_session.py` in team files. Run `robot --dryrun` on the changed suite. Update the knowledge (section 17). Show a diff summary.
**Ask:** "The test is added. Do you want me to create a branch and commit these changes?"

### Stage 7 - Branch and commit (only on yes)
Propose branch `ai-scriptgen/<test-case-id>-<YYYYMMDD>` and message `test(<module>): add <test case ID> <title> [ai-generated]`; let the user change them. Commit only the Stage 6 files; never stage anything under `ai_generated_tests/drafts/` or `.ai_session/`. Ask before pushing and again before opening a pull request. Never merge.

If the user says no or stop at any stage, stop there, keep the files, and summarise what exists.

### 5a. Full step list (Level 4 only)
When Playwright must walk known steps itself, run the extractor with `--steps "<keyword>"` for each keyword on the route and follow `knowledge/.extract/steps.json` exactly: every inner library step, frame switches (`FRAME`), new windows (`WINDOW`) and waits (`WAIT`) included. Steps marked `CONDITIONAL` or `RUNTIME` must be checked on the page before acting. Verify the page after every action (section 12). A mismatch means the translation is wrong, never that the keyword is broken.

## 6. Diagnosis before any fix
1. **Read the first failing step** in `output.xml`/`log.html` and its exact error.
2. **Look back.** Check the values that step used and the earlier steps that produced them. An earlier step that logged "No data retrieved from DB", returned an empty value, or a warning, is the real cause even if the error appears later (e.g. "client not found" at the search).
3. **Classify:** environment (database, vault, login, network, permissions, missing or wrong test data, wrong environment) or script (locator, wait, frame, step order, assertion in the new part).
4. **Environment or unclear → control test.** Run the smallest existing repo test that passes through the same step or screen, the normal way (`run-config.md`), headed. Do not change the script meanwhile.
   - **Control test fails the same way:** stop. Report in plain words: "My new test `<name>` (`<draft file>`) failed at `<step>` with `<exact error>`. I then ran your existing test `<full test name>` in `<suite file>`, and it failed at `<step>` with `<exact error>`. So the problem is the environment (`<database / login / data / ...>`), not the script. Please check `<what>` and run that test yourself; tell me "fixed, proceed" when it passes." Mask passwords, tokens and connection strings in errors. Wait. Environment failures never use up fix attempts.
   - **Control test passes:** the environment and the existing keywords are fine; the problem is in the draft. Fix the draft (Stage 5), never the keyword.
5. **Existing keyword suspected broken:** only when its control test also fails at that keyword for a non-environment reason (e.g. element not found on a changed screen). Report it as a stale existing keyword/locator with evidence, then ask: "Do you want me to use a temporary replacement only in this AI test, or stop so the team can fix it?" Never edit the team's files.
6. **Suggested locator fixes for the team.** For every existing locator proven stale (zero matches, or the wrong element, on the live screen while the screen itself is correct): find the same element on the live screen by its label, role or nearby text (Playwright through the door, or the saved screen), build a replacement in the repo's syntax using the locator priority in section 4, and prove it with `AI Check Locator` (exactly one visible match, right frame, the action works). Add it to the summary under "Suggested locator fixes for the team": `| File:line | Variable or keyword | Old locator | Suggested locator | Proof |`, with a ready-to-paste diff. If no replacement can be proven, say so. The team's files are never edited; the replacement is used only in this AI test, and only if the user approves.

## 7. Headed execution
- Browser library: pass headless false using the repo's existing variable (e.g. `--variable HEADLESS:false`) or the `New Browser    headless=${False}` argument already used by the repo's setup keyword.
- SeleniumLibrary: use the repo's browser variable with a non-headless value (e.g. `--variable BROWSER:chrome`, not `headlesschrome`).
- If the repo hard-codes headless mode in a setup keyword, do not edit it; tell the user, and use the draft's own setup override only if they approve.

## 8. Result integrity
- The result comes only from Robot Framework's output: the test's final status in `output.xml` and the process exit code.
- **PASS** only if the generated test ran from setup to teardown, every step executed, and every expected result was asserted and passed.
- Any failure in setup, login, navigation, a step, an assertion or teardown means **FAIL**. A skipped or not-run test is **NOT RUN**, never PASS.
- Dry-run success is reported as "syntax OK", never as "passed".
- Report the counts exactly as Robot gives them (passed, failed, skipped).

## 9. Sensitive data rules
Never write real values into comments, `[Documentation]`, `[Tags]`, test or keyword names, commit messages or knowledge files. This includes: client or customer IDs and names, account and reference numbers, user names, emails, phone numbers, addresses, passwords, tokens, environment URLs and hostnames, and any data value the user typed into the request.
- Describe by role instead: "Search client" not "Search client 102938".
- Put real values in the module's existing data or variable file under a descriptive variable name (e.g. `${TEST_CUSTOMER_ID}`), or reference an existing variable.
- Before showing any draft and before Stage 6, scan the new code for these patterns (digits-only IDs of 4+ characters, emails, URLs, values from the user's request) and replace them with variables.

## 10. Coding standards
- Section order: `*** Settings ***`, `*** Variables ***`, `*** Test Cases ***`, `*** Keywords ***`. Spacing and indentation identical to the surrounding files.
- Every test: `[Documentation]` with test case ID, title and one-line purpose; `[Tags]` with the repo's standard tags, the test case ID and `ai-generated`.
- Every new keyword: `[Documentation]`, `[Arguments]` if any, `RETURN` (or `[Return]` for older Robot versions used by the repo).
- One business action per keyword, Title Case in the repo's verb style, no duplicates of existing keywords.
- Explicit assertion for every expected result with a clear message. Explicit waits only. Choose the assertion that proves the outcome: option present in a list, checkbox or radio state, field value, exact or contained text, element visible or hidden, row present in a grid (by unique value), toast or success message, count. Prefer the assertion keywords the repo already uses.
- After every navigation step, wait for the screen's proof element before the next action (use the repo's wait keyword). Where the map lists a blocking message for that step, assert it is not present, so a missing precondition fails with a clear message instead of a confusing later error.
- Use existing setup and teardown; add cleanup if the test creates data and the repo does so elsewhere.
- No commented-out code, debug logs, `Sleep`, literals for credentials, URLs or test data.
- Run robotidy or robocop on new code only if the repo configures them.
- Every new keyword the AI creates carries `[Tags]    ai-generated` (keyword tags, Robot Framework 3.0+), so the badge and reports can tell new steps from existing ones.
- Never duplicate a setting in a file (one `Test Tags`/`Force Tags`, one `Suite Setup`, one `Documentation`); merge values into the existing line. Robot only uses the first copy and warns.

## 11. Marking generated code
Above every new test case, keyword and locator block:
```
# Generated by AI Robot Script Generator | <YYYY-MM-DD> | Source: <test case ID or generic description>
```
The Source is a test case ID (e.g. TC-1234) or a short generic description such as "Verify address type in dropdown" - never data values (section 9). Every generated test carries the tag `ai-generated`.

## 12. Step verification protocol (after every action, in exploration and in fixing)
Never assume an action worked. After each click, fill, select or navigation:
1. **Settle:** wait for loading to finish using the repo's own pattern (spinners or skeletons gone, network idle, element states). No fixed Sleep.
2. **Scan for interruptions:** modals, dialogs, native alerts, confirm boxes, toasts or snackbars, banners, inline validation errors, session-expired or login pages, new tabs or windows. Read their text.
3. **Confirm the expected state:** the target screen's proof element is visible, or the expected element state changed (checked, selected, value set, row added).
4. **Decide:**
   - Expected state present and no interruption: continue.
   - Interruption matches a known blocking message in the map: apply its fix (satisfy the precondition), re-plan, continue. Report it in the plan.
   - Interruption is a normal confirm (e.g. "Are you sure?") required by the test case: handle it the way existing keywords do.
   - Unknown interruption or expected state missing: take an accessibility or DOM snapshot, stop that path, and explain in plain words what is on screen. At most one retry, and only for clear timing issues.
5. Never report a screen as reached, or an element as "not found", until steps 1 to 3 are done.

## 13. Enterprise UI patterns (check `knowledge/ui-patterns.md` first; reuse the repo's handling keywords)
- **Frames and shadow DOM:** locate the frame or host first (Browser `>>>`, Selenium `Select Frame`); unselect afterwards.
- **Custom dropdowns (MUI, React-Select, Salesforce Lightning, combobox or listbox):** not native selects. Click to open, wait for the listbox (often rendered at the end of the page body), choose the option by role and accessible name, then verify the displayed value.
- **Checkboxes and radios with custom styling:** act on the input or its label as existing keywords do; verify the checked state, not just the click.
- **Date pickers:** prefer typing into the input if the repo does; otherwise navigate the calendar; verify the value.
- **Virtualised or paginated grids:** never rely on row index; filter or search first, scroll if needed, locate the row by a unique cell value, scope actions to that row.
- **Toasts and snackbars:** assert them immediately; they disappear.
- **New tab or window:** switch to it, verify, and switch back as the repo does.
- **Session timeout or forced re-login, unsaved-changes prompts, role-based hidden actions:** detect via the protocol and report; never work around permissions.
- **Dynamic IDs and duplicate elements:** scope locators to a stable container; prefer role, label, test IDs.

## 14. New features not yet in the knowledge (new dropdown, radio, checkbox, field, button, column)
A requested element missing from the knowledge is normal for new features. Never stop or report "not found" because the knowledge lacks it.
1. **Reach the section:** plan and replay the route to the nearest known screen the user named (sections 2b and 12). Confirm its proof element.
2. **Discover:** search in tiers, cheapest first, and stop as soon as one tier finds it. **Tier 0 (hint):** if the test case, requirement or user names a screen, section, panel or tab, start there. **Tier 1 (search the page code, no clicking):** search the whole DOM, including hidden elements, frames and shadow roots, for the user's words in text, labels, aria attributes, placeholders, titles and option values; a hit inside a hidden or collapsed container tells you exactly which container to open. **Tier 2 (scoped snapshot):** take an accessibility snapshot of the section's container only, not the full page. **Tier 3 (open containers):** only if tiers 1 and 2 found nothing, open the section's unopened tabs, panels or accordions one at a time, repeating tier 1 after each. Match the user's words against accessible names, labels, placeholders, titles, nearby text and headings, case-insensitive and allowing small wording differences. If not visible, look inside the section only: scroll, expand collapsed panels or accordions, open sub-tabs, check frames and shadow roots, and wait for loading. Never click save, submit, delete or similar during discovery. **Search budget:** counted in steps, not time: at most 10 discovery actions (searches, snapshots, opens, scrolls) and 3 snapshots, with a 5-minute safety limit that excludes page-loading waits (configurable as `discovery_budget`). Show one progress line per attempt ("Searching the section: opened 2 of 4 panels"). When the budget runs out, stop and go to step 3 with what was found.
3. **Decide:** exactly one confident match: continue. Several candidates: show them in plain words (label, type, position) and ask which one. None after step 2: ask the user one short question for a hint ("I couldn't find '<element>' in <section>. Which tab or panel is it under?"), then search once more using the hint within a fresh budget of 5 actions. Still none: say what the section does show and ask whether the feature is deployed to this environment.
4. **Identify the control type** from role and DOM (native or custom checkbox, radio group, text input, native select or custom dropdown, date picker, button, grid column) and handle it as section 13 says.
5. **Probe it before writing any script**, verifying the result each time (section 12):
   - checkbox or radio: set it, confirm the checked state changed; read all radio options;
   - text input: type a harmless test value, confirm the field value, then clear it;
   - dropdown: open it, read and record every option, select the requested option, confirm the displayed value;
   - button or link: confirm visible and enabled; click only if the test case requires it and it is not destructive;
   - check that it is enabled and not blocked by a precondition (e.g. another field must be set first); if blocked, find and add that precondition.
   Restore anything changed during probing unless the test needs it, and never save.
6. **Locator:** build it by the priority in section 4, then prove it with the judge (section 4), scoped to the section's container, and confirm it matches exactly one visible element.
7. **Use what was learned:** dropdown options read in step 5 can become assertions only if the test case asks for them. Never invent expected results from what the page shows.
8. Continue with Stage 4, Stage 5 (headed end-to-end run with automatic fixes) and the normal approval flow. After approval, the new element, its options and its preconditions are added to the knowledge as `learned (needs review)` (section 17).

## 14a. Mapping a whole new section (many controls)
Use when the test case touches a new section, panel, form or dialog, or more than two new controls on one screen.
1. **Find the section** with the tiered search in section 14 (heading, panel title or tab name from the test case). Confirm its container element.
2. **Inventory in one pass:** one scoped accessibility snapshot of the container plus one DOM read of its form controls (no clicking). For every control record: label, type (text, number, date, textarea, checkbox, radio group, native select, custom dropdown, toggle, button, link, grid), stable locator, default value, enabled or disabled, read-only, required, and limits from attributes (maxlength, min, max, step, pattern, input type, accept, aria-required, aria-invalid). Read every dropdown's options and every radio group's choices (opening a custom dropdown counts as one action).
3. **Accepts and rejects:** the attributes in step 2 give the rules at no cost. Probe validation by typing invalid values only when the test case checks validation or negative cases: enter the value, move focus away, read the inline message, then clear it. Never submit or save to trigger validation unless the test case requires it.
4. **Dependencies:** after each probe, re-read the container; record controls that appear, disappear, enable or change options (e.g. "Type = Other" reveals "Reason"). These become preconditions for those controls.
5. **Section map:** show the user a table: `| Control | Type | Required | Accepts | Options | Depends on | Locator |`.
6. **Map the test case to it:** for every step and expected result, name the control and action from the section map. Show `| TC step | Control | Action | Assertion |`. A step with no matching control: ask one hint question (section 14). Only test-case steps go into the script; the rest of the map is knowledge, not test steps.
7. Continue with Stage 4 and Stage 5 as normal. After approval, save the section map to the knowledge (`app-map.md` screen entry, locators file, glossary terms) as `learned (needs review)`, so the next test on this section needs no exploration.
8. **Budget:** the inventory uses 1 snapshot and 1 DOM read; dropdown opening, probing and dependency checks use the section 14 step budget, plus 1 action per control that must be opened. If the section has more than 40 controls, map only the controls the test case names and their dependencies, and say so.
9. **Hard cases** (icon-only buttons without labels, canvas or image-based controls, controls with only generated IDs): describe them by position and nearby text and ask the user to confirm before using them.

## 15. Mock mode (new features on a standalone mock screen)
A mock is a standalone HTML page (often with a mock API, no login) showing how a new feature will look inside the real screen. Triggered by `mock <link or file>` in the request, or when the user says the feature exists only on a mock.
1. Read the mock's HTML and open it in Playwright's own browser (`playwright` entry, not attach). Compare it with the knowledge of the real screen and list what already exists and what is new.
2. Explore only the new parts with sections 14 and 14a (popups, searches, results from the mock API, nested dialogs). Follow the test case steps one at a time: snapshot, act, snapshot again.
3. New keywords and locators go in one shared file `<feature>_new.resource` in `ai_generated_tests/drafts/<module>/` (moved with the tests). Locators are variables, so if developers change IDs, only this file changes. The mock link is a variable (`${MOCK_URL}`), never hard-coded in tests.
4. Judge every new locator in Robot on the mock (open the mock with the repo's browser keyword in a short run or rf-mcp session).
5. For each test case write two tests:
   - **Mock test:** opens `${MOCK_URL}`, runs the new-feature steps and checks. Runs now; report it as "passed on mock", never as "passed".
   - **Real test:** normal login and route with existing keywords, then the same new keywords. Tag it `waiting-for-release` and `robot:skip`, so it shows as skipped, never failed, until the feature is released. Also write a **route check** test (same route up to the section, ending with the section's proof element) and run it now on the real environment.
6. Knowledge learned from a mock is saved as `mock (needs real-app check)` and never becomes active until proven on the real app.
7. Report per test case: mock test result, route check result, real test "waiting for release".

## 16. Batch mode (many test cases in one file)
Triggered by `all` (or a list of IDs) with a test case file.
1. Read all test cases; show one plan table (test case, steps known/new, screens) and ask one confirmation.
2. Reach and explore each shared screen and each mock **once**; reuse the proven candidates for every test case.
3. One task per test case in the task list. Generate and run them one by one (Stages 4-5).
4. A script failure in one test case is recorded and the batch continues. An environment failure pauses the whole batch (section 6) until the user says "fixed, proceed".
5. End with one table: `| Test case | Mock test | Route check | Real test | Attempts | Problem |`, then one approval question for adding the passing tests.

## 17. Learning (the knowledge improves with every script)
Only for facts proven in this run, and only after the user approves Stage 6 (or explicitly asks), append with `Status: learned (needs review)`, the date and evidence (test run and step):
- new screens, transitions, preconditions, proof elements and section maps to `app-map.md`;
- new blocking messages with cause and fix;
- glossary terms the user used or chose (section 2a);
- new keywords and locators (`Source: ai-generated`);
- **lessons** to `knowledge/lessons.md`: one short rule per fix that worked, with the screen or keyword it applies to and the evidence, e.g. "`Search Client` works inside the search frame; select the database profile before searching". No data values.
The next `@qa-knowledge-setup refresh` and the reviewer confirm or reject learned entries.

## 18. AI activity indicator (on by default)
The browser shows an amber glow around the page and a **yellow two-line badge** with dark text in the top-right corner, so anyone watching (including managers with no testing background) can follow. It is invisible to locators and text checks and never blocks clicks.
- **Line 1**, bold, plain professional English: what is happening, always starting with "AI assistant is ...".
- **Line 2**, smaller grey: `Keyword: <step name>`; new steps the AI created show `(new, created by AI)` after the name. Hidden when no keyword is involved.
- **Robot runs:** add `--listener <path to skills/ai_activity_indicator.py>` (find it by name under `skills/`). It fills both lines automatically from the business step names and writes `ai-timing.json` next to `output.xml`. Include it in the rerun command and say it is optional.
- **rf-mcp sessions:** run every existing keyword through `AI Run Step    <keyword>    <arguments...>`: it shows the badge before the step, redraws it afterwards (page loads remove it) and records the time taken for the speed suggestions. For anything else call `AI Set Label    <line 1>    <keyword name>`. `AI Open Door` and `AI Close Door` draw the badge themselves ("AI assistant is reviewing this page (nothing will be saved)", "AI assistant is continuing with the existing steps"), so it also shows on the page Playwright attaches to.
- **Playwright's own browser (mock screens):** the badge loads through the Playwright MCP init script; update it with `window.__aiSetLabel('<line 1>', '<keyword or element>')`.
- **Approved line-1 wording:** AI assistant is starting the browser / opening the application / preparing the test environment / logging in / opening the client / finding the client / opening the page / reviewing this page / looking for <field name> / checking the new field / entering the details / selecting an option / updating a setting / checking the result / running the full test (attempt n of 3); "Test passed"; "Test needs attention". Never show arguments, client names, IDs, URLs, file paths or error text in the badge.
- The badge is drawn inside the page, so Playwright snapshots do not list it; confirm it by looking at the screen.
- Never add the indicator or `ai_session.py` to team files or CI. If a run behaves differently with it, rerun without it and tell the user. If the user says "no indicator", skip it for the session.

## 19. Task list and summary report
**Task list:** use the agent's own task or to-do tool (Devin task list; Copilot to-do list if enabled). Build it from the user's own steps, each saying whether it reuses knowledge or explores something new, for example:
0. Check the environment and connections
1. Understand your request: log in, go to Customer Addresses, tick Preferred Contact
2. Step 1, log in: known, reusing `Login To Portal`
3. Step 2, open the customer and Customer Addresses: known, route from test `<name>`, client selection added first
4. Step 3, Preferred Contact checkbox: new, exploring the screen
5. Prove the new locator
6. Write the draft script
7. Run it in the browser (attempt n of 3)
8. Move it to verified and report
9. Ask about adding it to the suite
Tick each task as it finishes; mark skipped ones as skipped. Describe data by role ("a client"), never by value. Mirror the list with ticks (✅ done, ⏳ running, ⏭ skipped, ❌ failed) in `ai_generated_tests/progress.md`, overwritten per run, as a backup when the tool shows no list.
**Summary report** at the end of every run, shown in chat and saved as `results/ai-scriptgen/summary-<test case>.md`, written in plain professional English for a manager first, details second: steps reused from knowledge vs new; new locators and keywords added; fallback level used; attempts used; environment problems found (with the control test name); time taken; final result and file paths.
**Timing and speed suggestions (never edits):** read `ai-timing.json` from the passing run (and `.ai_session/timing.json` from `AI Run Step` in the rf-mcp session). For every existing keyword that took more than 20 seconds, or spent more than a third of its time in `Sleep` or long waits, open its source lines and add a section "Suggested speed improvements for the team" to the summary: keyword name, file and line, time taken, the cause (e.g. "fixed Sleep 10s after the page is already loaded"), and a suggested change as a small diff (e.g. replace `Sleep` with the repo's wait-until keyword on the element the next step uses). These are suggestions only: the generated test keeps using the existing keyword unchanged, and the team decides.

## 20. Playwright output (only when asked)
Same stages, rules and marking. Write in the existing Playwright project's language and structure (ask where if none); prefer `getByRole`, `getByTestId`, `getByLabel`; web-first assertions; credentials from environment variables; run headed (`--headed`).

## 21. Error handling
- Ambiguous step: ask; never guess.
- Several candidate keywords: choose by preference rules, list alternatives in the plan.
- Element not found: run the full discovery in section 14 first; only then report what is visible and ask whether the feature is deployed to this environment.
- Login or environment failure: section 6; never retry login repeatedly.
- rf-mcp session error (e.g. text encoding crash, variable not defined): do not work around it by setting values by hand; restart the session with the run configuration, or drop to the next fallback level and say so.
- Fix attempts exhausted: report FAIL with the last error and diagnosis; leave the draft in `ai_generated_tests/drafts/`.
