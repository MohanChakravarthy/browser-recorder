"""
ai_session.py - Robot Framework helper library used ONLY by the AI skills (robot-script-generator).

It lets the AI agent, rf-mcp and Playwright MCP share one live browser safely:

    AI Save Screen        save main page + every frame + a list of controls + a screenshot
    AI Open Door          save the screen, then open a local "door" (127.0.0.1:9222) so
                          Playwright MCP can attach to the SAME browser. Does not block.
    AI Close Door         close the door immediately (also closes on timeout and at exit)
    AI Checkpoint         for a normal Robot run: open the door and PAUSE until the AI writes
                          .ai_session/continue (or the time limit passes), then close it
    AI Check Locator      the judge: prove a locator matches exactly one visible element in
                          the right frame and, optionally, that an action really changes state
    AI Set Label          show or update the yellow two-line AI status badge
    AI Run Step           run one existing keyword in an rf-mcp session with the badge shown before
                          and redrawn after (page changes wipe it), and record how long it took
    AI Check Variables    start-up check: report which required variables are missing or empty
                          (names only, never values)

Import it only in AI sessions or drafts, never in team suites or CI:
    Library    ../../skills/ai_session.py

Safety:
- The door listens on 127.0.0.1 only, forwards to the browser's own local debug port
  (chromedriver opens one in every Chrome run), and closes on command, after
  `door_timeout` seconds (default 1800), and when the Python process ends.
- Saved screens can contain application data. They go to .ai_session/ (git-ignored) and the
  generator deletes them at the end of the run. Nothing here clicks Save/Submit/Delete.
- Works with SeleniumLibrary (door + all keywords) and the Browser library (all keywords
  except the door; the Browser library manages its own Chromium - use the saved screen).
"""
import atexit
import json
import os
import re
import select
import socket
import socketserver
import threading
import time
from datetime import datetime

ROBOT_LIBRARY_SCOPE = "GLOBAL"

SESSION_DIR = os.environ.get("AI_SESSION_DIR", ".ai_session")
DOOR_HOST = "127.0.0.1"

CONTROLS_JS = r"""
return (function () {
  const out = [];
  const q = 'input,select,textarea,button,a[href],[role],[contenteditable="true"],label';
  const els = Array.from(document.querySelectorAll(q)).slice(0, 600);
  for (const el of els) {
    const r = el.getBoundingClientRect();
    const st = window.getComputedStyle(el);
    const visible = r.width > 0 && r.height > 0 && st.visibility !== 'hidden' && st.display !== 'none';
    let label = el.getAttribute('aria-label') || '';
    if (!label && el.id) {
      const l = document.querySelector('label[for="' + CSS.escape(el.id) + '"]');
      if (l) label = l.innerText.trim();
    }
    if (!label && el.closest('label')) label = el.closest('label').innerText.trim();
    const item = {
      tag: el.tagName.toLowerCase(), type: el.getAttribute('type') || '',
      role: el.getAttribute('role') || '', id: el.id || '', name: el.getAttribute('name') || '',
      testid: el.getAttribute('data-testid') || el.getAttribute('data-qa') || '',
      label: (label || '').slice(0, 120), text: (el.innerText || '').trim().slice(0, 80),
      placeholder: el.getAttribute('placeholder') || '', visible: visible,
      disabled: !!el.disabled || el.getAttribute('aria-disabled') === 'true',
      required: !!el.required || el.getAttribute('aria-required') === 'true',
      checked: (el.type === 'checkbox' || el.type === 'radio') ? !!el.checked :
               (el.getAttribute('aria-checked') || null),
      maxlength: el.getAttribute('maxlength') || '', pattern: el.getAttribute('pattern') || ''
    };
    if (el.tagName === 'SELECT') item.options = Array.from(el.options).slice(0, 100).map(o => o.text.trim());
    out.push(item);
  }
  return JSON.stringify(out);
})();
"""

_INDICATOR_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "ai_activity_indicator.js")


def _badge_script(text, keyword=""):
    """Full indicator script plus the label, so the badge is drawn even on a page that
    Playwright attached to (its init script only runs on pages Playwright opens itself)."""
    try:
        js = open(_INDICATOR_FILE, encoding="utf-8").read()
    except Exception:
        js = ""
    t, k = json.dumps(str(text)[:90]), json.dumps(str(keyword or "")[:80])
    return ("window.__aiLabelText = %s; window.__aiKeywordText = %s;\n" % (t, k)) + js + \
           "\ntry { window.__aiSetLabel && window.__aiSetLabel(%s, %s) } catch (e) {}" % (t, k)


# ----------------------------------------------------------------------------- door (TCP proxy)
class _Pipe(socketserver.BaseRequestHandler):
    def handle(self):
        door = self.server.door
        try:
            upstream = socket.create_connection(door.target, timeout=10)
        except OSError:
            return
        door._track(self.request, upstream)
        socks = [self.request, upstream]
        try:
            while not door.closed:
                r, _, _ = select.select(socks, [], [], 0.5)
                for s in r:
                    data = s.recv(65536)
                    if not data:
                        return
                    (upstream if s is self.request else self.request).sendall(data)
        except OSError:
            pass
        finally:
            for s in socks:
                try:
                    s.close()
                except OSError:
                    pass


class _Server(socketserver.ThreadingTCPServer):
    allow_reuse_address = True
    daemon_threads = True


class _Door:
    def __init__(self, port, target, timeout):
        self.target = target
        self.closed = False
        self._socks = []
        self._lock = threading.Lock()
        self.server = _Server((DOOR_HOST, port), _Pipe)
        self.server.door = self
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
        self.thread.start()
        self.timer = threading.Timer(timeout, self.close)
        self.timer.daemon = True
        self.timer.start()

    def _track(self, *socks):
        with self._lock:
            self._socks.extend(socks)

    def close(self):
        if self.closed:
            return
        self.closed = True
        try:
            self.timer.cancel()
        except Exception:
            pass
        with self._lock:
            for s in self._socks:          # cut live connections immediately
                try:
                    s.shutdown(socket.SHUT_RDWR)
                except OSError:
                    pass
                try:
                    s.close()
                except OSError:
                    pass
        try:
            self.server.shutdown()
            self.server.server_close()
        except Exception:
            pass


# ----------------------------------------------------------------------------- library
class ai_session:
    ROBOT_LIBRARY_SCOPE = "GLOBAL"

    def __init__(self, door_port=9222, door_timeout=1800, session_dir=SESSION_DIR):
        self.door_port = int(door_port)
        self.door_timeout = int(door_timeout)
        self.session_dir = session_dir
        self._door = None
        atexit.register(self._close_quietly)

    # -- helpers -------------------------------------------------------------------
    def _lib(self):
        from robot.libraries.BuiltIn import BuiltIn
        bi = BuiltIn()
        for name in ("SeleniumLibrary", "Browser"):
            try:
                return name, bi.get_library_instance(name)
            except Exception:
                continue
        raise RuntimeError("No SeleniumLibrary or Browser library is imported in this session.")

    def _state(self, **kw):
        os.makedirs(self.session_dir, exist_ok=True)
        path = os.path.join(self.session_dir, "state.json")
        state = {}
        if os.path.exists(path):
            try:
                state = json.load(open(path, encoding="utf-8"))
            except Exception:
                state = {}
        state.update(kw)
        state["updated_at"] = datetime.now().isoformat(timespec="seconds")
        with open(path, "w", encoding="utf-8") as f:
            json.dump(state, f, indent=1)
        return state

    def _close_quietly(self):
        try:
            if self._door:
                self._door.close()
        except Exception:
            pass

    def _selenium_frames(self, driver, depth=0, path=()):
        """Yield (path, page_source) for every frame, max 3 levels deep."""
        from selenium.webdriver.common.by import By
        out = []
        if depth > 3:
            return out
        frames = driver.find_elements(By.CSS_SELECTOR, "iframe,frame")
        for i, fr in enumerate(frames):
            ident = fr.get_attribute("id") or fr.get_attribute("name") or f"index{i}"
            try:
                driver.switch_to.frame(fr)
                out.append((path + (ident,), driver.page_source))
                out.extend(self._selenium_frames(driver, depth + 1, path + (ident,)))
            except Exception:
                pass
            finally:
                driver.switch_to.default_content()
                for p in path:                       # re-enter the parent chain
                    try:
                        driver.switch_to.frame(p if not p.startswith("index") else int(p[5:]))
                    except Exception:
                        break
        return out

    # -- keywords ------------------------------------------------------------------
    def ai_set_label(self, text, keyword=""):
        """Show the yellow AI badge (drawing it if missing). Line 1 is plain English
        ("AI assistant is logging in"), line 2 shows "Keyword: <name>" (hidden when empty).
        Step names only, never data."""
        try:
            kind, lib = self._lib()
            script = _badge_script(text, keyword)
            if kind == "SeleniumLibrary":
                lib.driver.switch_to.default_content()
                lib.driver.execute_script(script)
            else:
                lib.evaluate_javascript(None, "() => {" + script + "}")
        except Exception:
            pass

    def ai_save_screen(self, name="screen"):
        """Save page source, every frame's source, a controls list and a screenshot.

        Returns the folder path. Files: page.html, frames/<path>.html, frames.json,
        controls.json (main page), screenshot.png.
        """
        kind, lib = self._lib()
        stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
        folder = os.path.join(self.session_dir, "screens", f"{stamp}-{re.sub(r'[^\w-]', '_', name)}")
        os.makedirs(os.path.join(folder, "frames"), exist_ok=True)
        frame_map = []
        if kind == "SeleniumLibrary":
            d = lib.driver
            d.switch_to.default_content()
            open(os.path.join(folder, "page.html"), "w", encoding="utf-8").write(d.page_source)
            try:
                open(os.path.join(folder, "controls.json"), "w", encoding="utf-8").write(
                    d.execute_script(CONTROLS_JS) or "[]")
            except Exception:
                pass
            for path, src in self._selenium_frames(d):
                fn = "__".join(path) + ".html"
                open(os.path.join(folder, "frames", fn), "w", encoding="utf-8").write(src)
                frame_map.append({"frame_path": list(path), "file": "frames/" + fn})
            d.switch_to.default_content()
            try:
                d.save_screenshot(os.path.join(folder, "screenshot.png"))
            except Exception:
                pass
            url = d.current_url
        else:
            open(os.path.join(folder, "page.html"), "w", encoding="utf-8").write(lib.get_page_source())
            try:
                lib.take_screenshot(filename=os.path.abspath(os.path.join(folder, "screenshot")))
            except Exception:
                pass
            url = lib.get_url()
        json.dump(frame_map, open(os.path.join(folder, "frames.json"), "w"), indent=1)
        self._state(last_screen=folder, url_host=re.sub(r"^(\w+://[^/]+).*", r"\1", url or ""))
        return folder

    def ai_open_door(self, label="AI assistant is reviewing this page (nothing will be saved)"):
        """Save the screen, then open the local door to this browser. Returns the door URL.

        Does not block: rf-mcp keeps control, Playwright MCP (playwright-attach) can join.
        SeleniumLibrary only; with the Browser library it saves the screen and returns NONE.
        """
        folder = self.ai_save_screen("door")
        self.ai_set_label(label)
        kind, lib = self._lib()
        if kind != "SeleniumLibrary":
            self._state(door="unavailable (Browser library)", in_control="ai")
            return "NONE"
        caps = lib.driver.capabilities or {}
        dbg = None
        for key, val in caps.items():
            if isinstance(val, dict) and "debuggerAddress" in val:
                dbg = val["debuggerAddress"]
        if not dbg:
            self._state(door="unavailable (no debuggerAddress; use Chrome or Edge)", in_control="ai")
            return "NONE"
        host, port = dbg.rsplit(":", 1)
        host = "127.0.0.1" if host in ("localhost", "127.0.0.1", "") else host
        if self._door and not self._door.closed:
            self._door.close()
        self._door = _Door(self.door_port, (host, int(port)), self.door_timeout)
        url = f"http://{DOOR_HOST}:{self.door_port}"
        self._state(door=url, door_open=True, in_control="playwright", screen=folder,
                    door_closes_after_s=self.door_timeout)
        return url

    def ai_close_door(self, label="AI assistant is continuing with the existing steps"):
        """Close the door now and cut any Playwright connection."""
        if self._door:
            self._door.close()
        self._state(door_open=False, in_control="rf-mcp")
        self.ai_set_label(label)

    def ai_checkpoint(self, timeout=600, name="checkpoint"):
        """For a normal Robot run (fallback level 3): open the door and pause until the AI
        creates .ai_session/continue, or until `timeout` seconds pass. Then close the door."""
        flag = os.path.join(self.session_dir, "continue")
        if os.path.exists(flag):
            os.remove(flag)
        door = self.ai_open_door()
        self._state(paused=True, checkpoint=name, door=door,
                    resume_by=f"create the file {flag}")
        end = time.time() + int(timeout)
        while time.time() < end and not os.path.exists(flag):
            time.sleep(1)
        self.ai_close_door()
        resumed = os.path.exists(flag)
        if resumed:
            os.remove(flag)
        self._state(paused=False, resumed_by="signal" if resumed else "timeout")
        return "continued" if resumed else "timeout"

    def ai_run_step(self, keyword, *args):
        """Run an existing keyword exactly as given (rf-mcp sessions), with the badge.

        Line 1 is plain English derived from the keyword name, line 2 shows the keyword.
        The badge is drawn before the step and again after it, because page loads remove it.
        Duration is appended to .ai_session/timing.json for the speed suggestions.
        Returns the keyword's return value. Failures are re-raised unchanged.
        """
        from robot.libraries.BuiltIn import BuiltIn
        line1, line2 = "AI assistant is running a test step", keyword
        try:
            import importlib.util
            spec = importlib.util.spec_from_file_location(
                "ai_activity_indicator", os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                                      "ai_activity_indicator.py"))
            ind = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(ind)
            if "${" not in keyword:
                line1, line2 = ind.friendly_label(keyword)
        except Exception:
            pass
        self.ai_set_label(line1, line2)
        start = time.time()
        status = "PASS"
        try:
            return BuiltIn().run_keyword(keyword, *args)
        except Exception:
            status = "FAIL"
            raise
        finally:
            secs = round(time.time() - start, 2)
            try:
                os.makedirs(self.session_dir, exist_ok=True)
                path = os.path.join(self.session_dir, "timing.json")
                rows = json.load(open(path, encoding="utf-8")) if os.path.exists(path) else []
                rows.append({"keyword": keyword, "seconds": secs, "status": status})
                json.dump(rows, open(path, "w", encoding="utf-8"), indent=1)
            except Exception:
                pass
            self.ai_set_label(line1, line2)

    def ai_check_variables(self, *names):
        """Start-up check. For each variable name (e.g. ${URL}, ${DB_HOST}) report OK, EMPTY or
        MISSING. Never returns or logs values. Fails listing the problems, so the AI can stop
        and tell the user before any test step runs."""
        from robot.libraries.BuiltIn import BuiltIn
        bi = BuiltIn()
        result, problems = {}, []
        for n in names:
            name = n if n.startswith(("${", "@{", "&{")) else "${%s}" % n
            try:
                val = bi.get_variable_value(name)
            except Exception:
                val = None
            state = "MISSING" if val is None else ("EMPTY" if str(val).strip() == "" else "OK")
            result[name] = state
            if state != "OK":
                problems.append(f"{name} {state}")
        self._state(variables_check=result)
        if problems:
            raise AssertionError("Start-up check failed: " + ", ".join(problems))
        return result

    def ai_check_locator(self, locator, frame=None, action=None, value=None):
        """The judge. Proves `locator` (SeleniumLibrary syntax) inside `frame` (a frame
        locator, or a list joined by ' >> ' for nested frames):

        - exactly one element matches, and it is visible
        - if `action` is given (click | check | uncheck | type | select), performing it
          changes the state as expected (type/select need `value`)

        Always returns to the main page. Fails with a clear message otherwise.
        Never use it on Save/Submit/Delete buttons.
        """
        kind, lib = self._lib()
        if kind != "SeleniumLibrary":
            raise RuntimeError("AI Check Locator supports SeleniumLibrary; for Browser use "
                               "'Get Element Count' and 'Get Element States' directly.")
        lib.unselect_frame()
        try:
            if frame:
                for f in str(frame).split(" >> "):
                    lib.select_frame(f.strip())
            els = lib.find_elements(locator)
            visible = [e for e in els if e.is_displayed()]
            if len(els) == 0:
                raise AssertionError(f"Locator matched 0 elements: {locator}")
            if len(visible) != 1:
                raise AssertionError(f"Locator must match exactly 1 visible element, matched "
                                     f"{len(visible)} visible of {len(els)}: {locator}")
            el = visible[0]
            result = {"tag": el.tag_name, "enabled": el.is_enabled()}
            if action:
                a = action.lower()
                if a in ("check", "uncheck"):
                    want = a == "check"
                    if el.is_selected() != want:
                        el.click()
                    if el.is_selected() != want:
                        raise AssertionError(f"'{a}' did not change the state of {locator}")
                elif a == "click":
                    el.click()
                elif a == "type":
                    el.clear()
                    el.send_keys(value or "")
                    if (el.get_attribute("value") or "") != (value or ""):
                        raise AssertionError(f"Typed value did not stick in {locator}")
                elif a == "select":
                    from selenium.webdriver.support.select import Select
                    Select(el).select_by_visible_text(value)
                    if Select(el).first_selected_option.text.strip() != str(value).strip():
                        raise AssertionError(f"Option '{value}' was not selected in {locator}")
                else:
                    raise ValueError(f"Unknown action: {action}")
                result["action"] = a
            os.makedirs(self.session_dir, exist_ok=True)
            cands = os.path.join(self.session_dir, "proven.json")
            proven = []
            if os.path.exists(cands):
                try:
                    proven = json.load(open(cands, encoding="utf-8"))
                except Exception:
                    proven = []
            proven.append({"locator": locator, "frame": frame, "action": action,
                           "at": datetime.now().isoformat(timespec="seconds")})
            json.dump(proven, open(cands, "w", encoding="utf-8"), indent=1)
            return result
        finally:
            lib.unselect_frame()
