# Tester quick guide

1. One time: `@qa-knowledge-setup build` (or `build <folder | .robot file | topic>`)
2. After pulling new changes: `@qa-knowledge-setup refresh`
3. Generate a script: `@robot-script-generator TC-1234`, a test case `.md` file, or one plain sentence
   - many test cases at once: `@robot-script-generator <file.md> all`
   - new feature on a mock screen: add `mock <mock link>`
4. Watch the task list tick and the yellow "AI assistant is ..." badge in the browser. The generator reuses your existing
   keywords, explores only what is new, proves every new locator, runs the test and fixes it itself.
5. It asks only before adding the test to the suite and before committing.
6. If it says the environment is the problem (database, login, data), fix that, run the existing test
   it names yourself, then reply "fixed, proceed".

In VS Code Copilot, type `/qa-knowledge-setup` or `/robot-script-generator` instead of `@...`.
