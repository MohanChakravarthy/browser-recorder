# 15-minute check: can Playwright join rf-mcp's browser?

This proves the one part that cannot be tested outside your machine. If it fails, nothing breaks:
the generator drops to fallback level 2 (saved screen files) and the rest still works.

## Before you start
1. `skills/ai_session.py` and `skills/ai_activity_indicator.js` are in your repo.
2. Devin (or VS Code) MCP settings contain `robotmcp`, `playwright` and `playwright-attach`
   (copy from `setup/mcp-config-examples/`, change the paths, restart the editor).
   If your MCP settings allow a working folder for `robotmcp`, set it to your repo root.
3. An existing test that reaches the screen passes when you run it the normal way.
4. You know the command-line variables of that normal run (for example `--variable ENV:<env>`).
   After a knowledge build they are in `knowledge/run-config.md`.

## Paste this into a new chat (fill in the <...> parts)
```
Use only the robotmcp tools for this check. Do not create or change any repo files.
1. Start one session that reproduces my normal run:
   - first set these command-line variables with Set Global Variable: <e.g. ENV=UAT>
   - the working folder (${EXECDIR}) is the repo root: <repo root path>
   - then import exactly the Library, Resource and Variables lines of <your suite file>,
     with the same arguments, plus Library skills/ai_session.py.
   Import the secrets / vault loader only once. If an import cannot be found, stop and tell me
   the file and the import line. Never type URLs, user names or passwords yourself.
2. Run the suite setups once: folder init files (__init__.robot or __init__.txt) from the top
   folder down (skip any without a setup, do not ask), then the suite's own Suite Setup.
3. Run the steps of the existing test <test name> one by one, in a visible browser, until its
   main screen is open, before any save step. Stop at the first failure and tell me the error.
4. Run: AI Open Door. Tell me the URL it returns.
5. Use the playwright-attach tools: take a snapshot of the current page and tell me the page
   title and the visible section names and buttons. Do not click anything.
6. Back in robotmcp, run: AI Close Door.
7. Close the browser and end the session, even if an earlier step failed.
8. Report which steps worked, and any locator that no longer matches the screen.
```

## What good looks like
- Step 4 returns `http://127.0.0.1:9222`.
- **Look at the browser yourself:** an amber glow around the page and a yellow badge, top right,
  saying "AI assistant is reviewing this page (nothing will be saved)". The badge is drawn
  inside the page in a hidden layer, so Playwright's snapshot will not list it; that is expected.
- Step 5 sees the same logged-in page (same title, your sections). No new browser opens.
- After step 6 the badge says "AI assistant is continuing with the existing steps".
- After step 7 no browser window is left open.

## If it fails
| What you see | Meaning | What happens |
|---|---|---|
| Step 1 cannot find an import | The session is not running from the repo root, or a path variable is missing | Set the working folder, or add the variable in step 1 |
| Step 2 says a URL or credential variable is missing | The secrets loader did not get the environment, or was not imported | Check the variables in step 1 and the loader's arguments |
| Step 4 returns `NONE` | No Chrome debug address (not Chrome/Edge, or Browser library) | Generator uses level 2: saved screen files only |
| Step 5 cannot connect | Port 9222 blocked or busy | Change `door_port` in the Library import and in `playwright-attach`, or use level 2 |
| Step 5 opens a new blank browser | `playwright-attach` is missing `--cdp-endpoint` | Fix the MCP entry and restart |
| A step of your test fails on a missing element | The existing test's locator is out of date in this environment | Report it to the team; the generator never replaces it silently |
