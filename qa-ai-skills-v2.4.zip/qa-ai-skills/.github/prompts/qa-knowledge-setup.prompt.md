---
mode: agent
description: Build, refresh, rebuild or check the QA knowledge base (whole repo, a folder, a .robot file or a topic).
---
Follow every instruction in [qa-knowledge-setup](../../skills/qa-knowledge-setup/qa-knowledge-setup.md) exactly, including the task list and progress messages.

Command: ${input:command:build | refresh | rebuild | status, optionally followed by a folder, .robot file or topic}
