---
mode: agent
description: Generate a proven Robot Framework test from a test case ID, a test case file (add "all" for batch, "mock <link>" for mock screens) or a plain request.
---
Follow every instruction in [robot-script-generator](../../skills/robot-script-generator.md) exactly, including the task list, the run configuration, the judge and the approval questions.

Request: ${input:request:TC-1234, a test case .md file, or what to check}
