// ai_activity_indicator.js - blue "AI" border and live label for Playwright MCP exploration.
// Loaded through Playwright MCP's --init-script option, so it runs on every page and
// survives navigation without the AI having to remember it.
// Safe: ignores the mouse (pointer-events: none), label lives in a closed shadow root (text
// checks never see it), styles are set from script (works with strict CSP), errors swallowed.
// The AI can change the label:  window.__aiSetLabel('Looking for Settle Account Only checkbox')
// Colours: RBC blue (#005DAA) border and badge, light blue glow.
(() => {
  try {
    if (window.top !== window.self) return;            // main page only, not inside frames
    const DEFAULT = window.__aiLabelText || 'AI: Playwright exploring the page';
    // The badge is kept on window so a second injection (e.g. from the Robot listener after
    // the init script) still updates the same badge instead of drawing a new one.
    window.__aiSetLabel = (t) => {
      try {
        window.__aiLabelText = String(t || DEFAULT).slice(0, 90);
        if (window.__aiBadge) window.__aiBadge.textContent = window.__aiLabelText;
      } catch (e) {}
    };
    const draw = () => {
      try {
        if (document.getElementById('ai-activity-indicator')) return;
        const root = document.documentElement;
        if (!root) return;
        const d = document.createElement('div');
        d.id = 'ai-activity-indicator';
        d.setAttribute('aria-hidden', 'true');
        Object.assign(d.style, { position: 'fixed', top: '0', left: '0', right: '0', bottom: '0',
          pointerEvents: 'none', zIndex: '2147483647', borderRadius: '6px',
          boxShadow: 'inset 0 0 0 3px rgba(0,93,170,0.9), inset 0 0 28px 6px rgba(102,178,255,0.55)' });
        const sr = d.attachShadow({ mode: 'closed' });
        const badge = document.createElement('span');
        window.__aiBadge = badge;
        badge.textContent = window.__aiLabelText || DEFAULT;
        Object.assign(badge.style, { position: 'absolute', top: '8px', right: '12px',
          font: '600 12px/1.2 Segoe UI, Arial, sans-serif', color: '#fff', maxWidth: '60vw',
          background: 'rgba(0,93,170,0.92)', padding: '5px 9px', borderRadius: '10px',
          whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' });
        sr.appendChild(badge);
        root.appendChild(d);
        if (d.animate) d.animate([
          { boxShadow: 'inset 0 0 0 2px rgba(0,93,170,0.6), inset 0 0 14px 2px rgba(102,178,255,0.35)' },
          { boxShadow: 'inset 0 0 0 4px rgba(0,93,170,1), inset 0 0 40px 10px rgba(102,178,255,0.75)' }
        ], { duration: 1600, iterations: Infinity, direction: 'alternate', easing: 'ease-in-out' });
      } catch (e) {}
    };
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', draw, { once: true });
    draw();
    // Re-draw if a single-page app replaces the document body.
    try { new MutationObserver(() => { if (!document.getElementById('ai-activity-indicator')) draw(); })
      .observe(document.documentElement, { childList: true }); } catch (e) {}
  } catch (e) {}
})();
