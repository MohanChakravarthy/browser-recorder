"""
ai_activity_indicator.py - blue "AI agent running test" border and live label during AI Robot runs.

Optional, visual only. Used by robot-script-generator for its own headed runs:
    robot --listener skills/ai_activity_indicator.py ... ai_generated_tests/drafts/<module>/<file>.robot
Never add this to test code, suites or CI pipelines. Normal runs are unaffected.

The label shows the current business keyword name only (never arguments or data), e.g.
    "AI agent running test: Open Client"

Safe by design:
- The overlay ignores the mouse (pointer-events: none), so it never blocks clicks.
- Its label sits in a closed shadow root, so text locators and "Page Should Contain" never see it.
- Styles are set from script (no <style> tag), so strict Content-Security-Policy pages still work.
- Re-applied after browser keywords, because page navigation removes it.
- Every error is swallowed: the indicator can never fail a test.
Colours: RBC blue (#005DAA) border and badge with a light blue glow.
Works with the Browser library (Playwright) and SeleniumLibrary. Robot Framework 4+.
"""
import os

ROBOT_LISTENER_API_VERSION = 2

_HERE = os.path.dirname(os.path.abspath(__file__))
_JS_FILE = os.path.join(_HERE, "ai_activity_indicator.js")

INDICATOR_JS = None      # loaded lazily from ai_activity_indicator.js (same folder)
_busy = False
_label = "AI agent running test"
_last_applied = None


def _js():
    global INDICATOR_JS
    if INDICATOR_JS is None:
        try:
            INDICATOR_JS = open(_JS_FILE, encoding="utf-8").read()
        except Exception:
            INDICATOR_JS = ""
    return INDICATOR_JS


def _library(class_name):
    try:
        from robot.libraries.BuiltIn import BuiltIn
        libs = BuiltIn().get_library_instance(all=True)
    except Exception:
        return None
    for lib in libs.values():
        if type(lib).__name__ == class_name:
            return lib
    return None


def _apply(libname):
    """Draw the border (if missing) and set the label text."""
    global _busy, _last_applied
    if _busy or not _js():
        return
    _busy = True
    script = ("window.__aiLabelText = %r;\n" % _label) + _js() + \
             "\ntry { window.__aiSetLabel && window.__aiSetLabel(%r) } catch (e) {}" % _label
    try:
        if libname == "Browser":
            lib = _library("Browser")
            if lib is not None:
                lib.evaluate_javascript(None, "() => {" + script + "}")
        elif libname == "SeleniumLibrary":
            lib = _library("SeleniumLibrary")
            if lib is not None:
                lib.driver.execute_script(script)
        _last_applied = _label
    except Exception:
        pass      # no page yet, page navigating, browser closed, frame selected: ignore
    finally:
        _busy = False


def start_keyword(name, attrs):
    """Track the current business (user) keyword name for the label."""
    global _label
    try:
        if not attrs.get("libname") and attrs.get("type", "Keyword") in ("Keyword", "KEYWORD", "SETUP", "TEARDOWN", "Setup", "Teardown"):
            kw = (attrs.get("kwname") or name or "").strip()
            if kw:
                _label = ("AI agent running test: " + kw)[:90]
    except Exception:
        pass


def end_keyword(name, attrs):
    libname = attrs.get("libname")
    if libname in ("Browser", "SeleniumLibrary"):
        low = (attrs.get("kwname") or name or "").lower()
        if "close" in low:
            return
        _apply(libname)


def start_test(name, attrs):
    global _label
    _label = "AI agent running test: " + (name or "")[:60]
