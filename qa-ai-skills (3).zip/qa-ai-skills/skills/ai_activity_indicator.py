"""
ai_activity_indicator.py - AI status badge and timing report during AI Robot runs (a Robot listener).

Optional. Used by robot-script-generator for its own headed runs:
    robot --listener skills/ai_activity_indicator.py ... ai_generated_tests/drafts/<module>/<file>.robot
Never add this to test code, suites or CI pipelines. Normal runs are unaffected.

1) Badge: an amber glow around the page and a yellow two-line badge a manager can follow:
       line 1 (bold):  "AI assistant is logging in"
       line 2 (grey):  "Keyword: Login To Portal"   (or "... (new, created by AI)")
   Business step names only, never arguments, client names, IDs or other data.

2) Timing report: writes ai-timing.json next to output.xml with, for every business
   (user) keyword: total time, time spent in fixed Sleep and in waits, and where it is
   defined. The generator uses it to suggest faster code to the team (it never edits it).

Safe by design: the overlay ignores the mouse, its text is invisible to locators and
"Page Should Contain" (closed shadow root), it works with strict CSP pages, it is re-drawn
after page navigation, and every error is swallowed so it can never fail a test.
Works with the Browser library (Playwright) and SeleniumLibrary. Robot Framework 4+.
"""
import json
import os
import re
import time

ROBOT_LISTENER_API_VERSION = 2

_HERE = os.path.dirname(os.path.abspath(__file__))
_JS_FILE = os.path.join(_HERE, "ai_activity_indicator.js")

LIBRARIES = {"builtin", "seleniumlibrary", "browser", "collections", "string", "operatingsystem",
             "datetime", "xml", "process", "screenshot", "dialogs", "telnet", "requestslibrary",
             "databaselibrary", "json", "jsonlibrary", "ai_session", "easter", "reserved"}

# Plain, professional wording by what a business step does (first match wins).
FRIENDLY = [
    (r"^(verify|validate|assert|ensure|expect|check that|confirm that)|should", "Checking the result"),
    (r"log ?in|sign ?in|authenticat", "Logging in"),
    (r"log ?out|sign ?out", "Logging out"),
    (r"open (the )?browser|launch|start (the )?app|new browser|open application", "Opening the application"),
    (r"vault|credential|config|load|setup|set up|initiali", "Preparing the test environment"),
    (r"(search|find|look ?up).*client|client.*(search|find|look ?up)", "Finding the client"),
    (r"search|find|look ?up|filter", "Finding the record"),
    (r"select (the )?client|choose (the )?client|open (the )?client", "Opening the client"),
    (r"navigate|go to|open|click .*tab|menu", "Opening the page"),
    (r"select|choose|pick", "Selecting an option"),
    (r"enter|fill|type|input|set ", "Entering the details"),
    (r"tick|check(box)?|uncheck|toggle", "Updating a setting"),
    (r"add|create|new ", "Adding a new item"),
    (r"save|submit|confirm", "Saving the changes"),
    (r"delete|remove", "Removing an item"),
    (r"close|teardown|clean", "Finishing up"),
]

INDICATOR_JS = None
_busy = False
_label = ("AI assistant is preparing the test", "")
_stack = []          # open user keywords: {"name", "start", "sleep", "wait", "source", "line"}
_timing = {}         # name -> aggregated timing
_outdir = None


def _js():
    global INDICATOR_JS
    if INDICATOR_JS is None:
        try:
            INDICATOR_JS = open(_JS_FILE, encoding="utf-8").read()
        except Exception:
            INDICATOR_JS = ""
    return INDICATOR_JS


def friendly_label(keyword_name, new=False):
    """Returns (line1, line2) for the two-line badge, e.g.
    ('AI assistant is logging in', 'Login To Portal'); new AI keywords get ' (new, created by AI)'."""
    name = re.sub(r"\s+", " ", (keyword_name or "").replace("_", " ")).strip()
    low = name.lower()
    action = "running a test step"
    for pattern, text in FRIENDLY:
        if re.search(pattern, low):
            action = text[0].lower() + text[1:]
            break
    line2 = (name + (" (new, created by AI)" if new else ""))[:80] if name else ""
    return ("AI assistant is " + action)[:90], line2


def _is_user_keyword(attrs):
    lib = (attrs.get("libname") or "").strip().lower()
    return lib not in LIBRARIES


def _library(class_name):
    try:
        from robot.libraries.BuiltIn import BuiltIn
        libs = BuiltIn().get_library_instance(all=True)
    except Exception:
        return None
    for lib in libs.values():
        if type(lib).__name__ == class_name:
            return lib
    return None


def _apply(libname):
    global _busy
    if _busy or not _js():
        return
    _busy = True
    l1, l2 = json.dumps(_label[0]), json.dumps(_label[1])
    script = ("window.__aiLabelText = %s; window.__aiKeywordText = %s;\n" % (l1, l2)) + _js() + \
             "\ntry { window.__aiSetLabel && window.__aiSetLabel(%s, %s) } catch (e) {}" % (l1, l2)
    try:
        if libname == "Browser":
            lib = _library("Browser")
            if lib is not None:
                lib.evaluate_javascript(None, "() => {" + script + "}")
        elif libname == "SeleniumLibrary":
            lib = _library("SeleniumLibrary")
            if lib is not None:
                lib.driver.execute_script(script)
    except Exception:
        pass      # no page yet, navigating, browser closed, inside a frame: ignore
    finally:
        _busy = False


# ------------------------------------------------------------------ listener methods
def start_suite(name, attrs):
    global _outdir
    try:
        from robot.libraries.BuiltIn import BuiltIn
        _outdir = BuiltIn().get_variable_value("${OUTPUT DIR}")
    except Exception:
        _outdir = None


def start_test(name, attrs):
    global _label
    _label = ("AI assistant is starting the test", (name or "")[:80])


def start_keyword(name, attrs):
    global _label
    try:
        if _is_user_keyword(attrs):
            kw = (attrs.get("kwname") or name or "").strip()
            _stack.append({"name": kw, "start": time.time(), "sleep": 0.0, "wait": 0.0,
                           "source": attrs.get("source"), "line": attrs.get("lineno")})
            if len(_stack) <= 2:          # top-level business steps only, not inner helpers
                tags = [str(t).lower() for t in (attrs.get("tags") or [])]
                _label = friendly_label(kw, new="ai-generated" in tags)
        else:
            low = (attrs.get("kwname") or name or "").lower()
            if (attrs.get("libname") in ("SeleniumLibrary", "Browser")
                    and ("open browser" in low or "new browser" in low or "new page" in low)):
                _label = ("AI assistant is opening the application (this can take a minute)", "")
    except Exception:
        pass


def end_keyword(name, attrs):
    try:
        libname = attrs.get("libname")
        low = (attrs.get("kwname") or name or "").lower()
        secs = (attrs.get("elapsedtime") or 0) / 1000.0
        if _is_user_keyword(attrs):
            if _stack:
                k = _stack.pop()
                t = _timing.setdefault(k["name"], {"keyword": k["name"], "calls": 0, "total_s": 0.0,
                                                   "sleep_s": 0.0, "wait_s": 0.0,
                                                   "source": k["source"], "line": k["line"]})
                t["calls"] += 1
                t["total_s"] = round(t["total_s"] + (time.time() - k["start"]), 2)
                t["sleep_s"] = round(t["sleep_s"] + k["sleep"], 2)
                t["wait_s"] = round(t["wait_s"] + k["wait"], 2)
        else:
            if _stack and low == "sleep":
                for k in _stack:
                    k["sleep"] += secs
            elif _stack and (low.startswith("wait") or "wait until" in low):
                for k in _stack:
                    k["wait"] += secs
            if libname in ("Browser", "SeleniumLibrary") and "close" not in low:
                _apply(libname)
    except Exception:
        pass


def close():
    try:
        folder = _outdir or os.getcwd()
        rows = sorted(_timing.values(), key=lambda r: -r["total_s"])
        with open(os.path.join(folder, "ai-timing.json"), "w", encoding="utf-8") as f:
            json.dump(rows, f, indent=1)
    except Exception:
        pass
