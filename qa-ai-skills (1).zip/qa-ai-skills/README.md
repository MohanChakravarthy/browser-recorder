# QA AI Skills (v2.2)

AI skills that learn a Robot Framework repo and turn AIDLC test cases into proven Robot scripts,
including new features shown only on mock screens. Works in Devin and VS Code (Copilot).

## What is in this folder
```
skills/
  qa-knowledge-setup/
    qa-knowledge-setup.md      one-step build / refresh / rebuild / status (v1.4.0)
    extract_repo.py            exact facts from your code with Robot's own parser (self-test: 14 OK)
  app-knowledge-builder.md     screens, flows, application map, glossary, run config (v1.3.1)
  keyword-knowledge-builder.md (v1.1.0)
  locator-knowledge-builder.md (v1.1.0)
  knowledge-reviewer.md        (v1.3.0)
  robot-script-generator.md    (v2.2.0)
  ai_session.py                save screen, open/close the door, judge locators (AI runs only)
  ai_activity_indicator.py     blue badge with plain-English status + timing report (listener)
  ai_activity_indicator.js     blue badge during Playwright exploration (init script)
  README.md                    tester quick guide
.github/prompts/               /robot-script-generator and /qa-knowledge-setup for VS Code Copilot
setup/
  mcp-config-examples/         Devin and VS Code MCP settings (robotmcp, playwright, playwright-attach)
  shared-browser-check.md      15-minute check that Playwright can join rf-mcp's browser
  gitignore-additions.txt      lines to add to .gitignore
```

## Install (once)
1. Copy `skills/` and `.github/` into the root of your QA repo (replace older skill files).
2. Add the lines from `setup/gitignore-additions.txt` to `.gitignore`.
3. Add the MCP entries from `setup/mcp-config-examples/` (fix the paths), keep your working
   `robotmcp` entry, and restart Devin / VS Code.
4. Run the self-test with the same Python you use for robot:
   `python skills/qa-knowledge-setup/extract_repo.py --self-test`  -> SELF-TEST PASSED, 14 OK lines.
5. Rebuild the knowledge on your branch:
   `@qa-knowledge-setup rebuild <your cross reference .robot file>`
6. Optional but recommended: `setup/shared-browser-check.md` (15 minutes).

## Use
- `@robot-script-generator TC-1234`
- `@robot-script-generator log in, open a client, go to Manage Cross Reference and tick Settle Account Only`
- `@robot-script-generator <test cases .md> all mock <mock link>`   (batch + mock mode)
In VS Code Copilot type `/robot-script-generator` or `/qa-knowledge-setup` instead.

## Safety
Read-only on your tests until you approve. Drafts in `ai_generated_tests/drafts/` (git-ignored),
passing tests in `ai_generated_tests/verified/`. Asks before adding to a suite, branching or
committing. No secrets or client data in code. `ai_session.py` and the indicator are never added
to team files or CI.
