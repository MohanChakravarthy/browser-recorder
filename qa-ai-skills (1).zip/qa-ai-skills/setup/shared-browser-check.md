# 15-minute check: can Playwright join rf-mcp's browser?

This proves the one part that could not be tested outside your machine. If it fails, nothing breaks:
the generator drops to fallback level 2 (saved screen files) and the demo still works.

## Before you start
1. `skills/ai_session.py` and `skills/ai_activity_indicator.js` are in your repo.
2. Devin (or VS Code) MCP settings contain `robotmcp`, `playwright` and `playwright-attach`
   (copy from `setup/mcp-config-examples/`, change the paths, restart the editor).
3. An existing cross reference test passes when you run it the normal way (UAT).

## Paste this into a new chat
```
Use only the robotmcp tools for this check. Do not create or change any files.
1. Start one session for the suite <your cross reference suite file>: the same Library,
   Resource and Variables imports as that suite, plus Library skills/ai_session.py.
2. Run every Suite Setup once: the folder init files (__init__.robot or __init__.txt; skip any with no setup) from the top folder down, then the
   suite's own Suite Setup. Run them only once.
3. Run the steps of the existing test <test name> one by one, in a visible browser, until the
   Manage Cross Reference screen is open. Stop at the first failure and tell me the error.
4. Run: AI Open Door. Tell me the URL it returns.
5. Now use the playwright-attach tools: take a snapshot of the current page and tell me the
   page title and whether you can see the Settle Account Only checkbox. Do not click anything.
6. Back in robotmcp, run: AI Close Door.
7. Report: did steps 1-6 work, and what did the badge in the browser say at step 4 and step 6?
```

## What good looks like
- Step 4 returns `http://127.0.0.1:9222`, and the badge says "Paused: AI exploring the page".
- Step 5 sees the same logged-in page (same title, the checkbox is listed). No new browser opens.
- Step 6 closes the door; the badge goes back to "AI agent running test".

## If it fails
| What you see | Meaning | What happens |
|---|---|---|
| Step 4 returns `NONE` | Chrome debug address not available (not Chrome/Edge, or Browser library) | Generator uses level 2: saved screen files only |
| Step 5 cannot connect | Port 9222 blocked or busy | Change `door_port` in the Library import and in `playwright-attach`, or use level 2 |
| Step 5 opens a new blank browser | `playwright-attach` is missing `--cdp-endpoint` | Fix the MCP entry and restart |
| Steps 1-3 fail | Session setup, not the door | Compare with `knowledge/run-config.md`; this is the same issue as a normal run |

Tell me the result; I'll set the default level in the generator accordingly.
